#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
br&roll (brsystemx1) — красное / чёрное: подсказчик по истории для рулетки
GTA5RP / Majestic / RMRP. Чисто для фана.

Установка:   pip install -r requirements.txt
Запуск:      python rol.py
"""
import math
import random
import time
import tkinter as tk
from tkinter import font as tkfont

try:
    import numpy as np
    from PIL import Image, ImageDraw, ImageFilter, ImageTk
except ImportError:
    raise SystemExit("Нужны библиотеки. Установи командой:  pip install -r requirements.txt")

RS = getattr(Image, "Resampling", Image)   # совместимость с разными версиями Pillow

# ───────────────────────── константы ─────────────────────────
SYSTEM_NAME = "brsystemx1"
W, H = 900, 664
BG_SCALE = 6                                  # фон считается в мини-разрешении и растягивается
BW, BH = W // BG_SCALE, -(-H // BG_SCALE)
FONT = "Segoe UI"

FRAME_MS = 8         # ~120 кадров/с для максимальной плавности
BG_DT = 0.05         # фон обновляется для плавного переливания

FG = "#eaf2ff"
DIM = "#9db2d4"
GOLD = "#f5d98a"
GREEN = "#7ee0b0"
AMBER = "#f0b46a"
PANEL_FADE = "#0e1834"
PANEL_FADE_RGB = (14, 24, 52)
CARD = "#122042"
CARD_OUT = "#2b4274"
BTN = "#16244a"
BTN_OUT = "#3d5a94"
BTN_ACTIVE_BLUE = "#5a85ef"  # Стильная синяя подсветка вместо желтой
TRACK = "#0b1430"
TRACK_OUT = "#27406e"
PANEL_RGBA = (9, 14, 32, 190)
PANEL_OUT = (120, 160, 225, 140)

CHIP = {
    "R": ("#d4455b", "#ffe1e5"),   # красная: заливка, кайма
    "B": ("#151a30", "#b9c9ee"),   # чёрная
}
GLOW = {"R": "#ff7d90", "B": "#8fb0ff"}

# Словари локализации
LANG = {
    "ru": {
        "NAME": {"R": "Красное", "B": "Чёрное"},
        "SHORT": {"R": "К", "B": "Ч"},
        "stats": "Статистика",
        "history": "История",
        "empty_history": "Пока пусто — внеси результаты",
        "predict_title": "Вероятные результаты",
        "eval_sys": "оценка системы",
        "signals": "Сигналы системы",
        "best_var": "Лучший вариант",
        "confidence": "Уверенность",
        "conf_low": "низкая",
        "conf_mid": "средняя",
        "conf_high": "высокая",
        "calc": "Считаю шансы…",
        "hint_empty": "Внеси результат (нужно от 5)",
        "need_more": "Собрано результатов:",
        "note_default": "Прогноз активируется после 5-го результата в истории.",
        "ask": "Как сыграла рекомендация",
        "btn_undo": "Отменить",
        "btn_clear": "Очистить",
        "hit": "Зашло",
        "miss": "Не зашло",
        "max_streak": "Макс. серия",
        "hits_lbl": "Зашло",
        "misses_lbl": "Не зашло",
        "series_lbl": "Серия",
        "chg_bar": "Смена цвета",
        "same_bar": "Серия продолжится",
        "titles": {"streak": "Серии", "pattern": "История", "balance": "Баланс", "zigzag": "Зигзаг"},
        "notes": [
            "Выпал один — может выпасть любой цвет, небольшой перевес на смену.",
            "Два подряд — большой шанс, что цвет сменится.",
            "Три подряд — не уверен, что серия продолжится: сигнал слабый.",
            "Четыре подряд — шанс смены цвета растёт."
        ],
        "note_long": "Серия из {} — очень высокий шанс смены цвета."
    },
    "en": {
        "NAME": {"R": "Red", "B": "Black"},
        "SHORT": {"R": "R", "B": "B"},
        "stats": "Statistics",
        "history": "History",
        "empty_history": "Empty yet — enter results",
        "predict_title": "Probable Outcomes",
        "eval_sys": "system score",
        "signals": "System Signals",
        "best_var": "Best Option",
        "confidence": "Confidence",
        "conf_low": "low",
        "conf_mid": "medium",
        "conf_high": "high",
        "calc": "Calculating...",
        "hint_empty": "Enter results (need 5+)",
        "need_more": "Results collected:",
        "note_default": "Prediction activates after 5 results in history.",
        "ask": "How did the recommendation perform?",
        "btn_undo": "Undo",
        "btn_clear": "Clear",
        "hit": "Hit",
        "miss": "Miss",
        "max_streak": "Max Streak",
        "hits_lbl": "Hits",
        "misses_lbl": "Misses",
        "series_lbl": "Streak",
        "chg_bar": "Color Change",
        "same_bar": "Streak Continues",
        "titles": {"streak": "Streaks", "pattern": "History", "balance": "Balance", "zigzag": "Zigzag"},
        "notes": [
            "Single drop — either color can drop, slight bias to change.",
            "Two in a row — high chance of color change.",
            "Three in a row — unsure if streak continues: weak signal.",
            "Four in a row — color change chance is growing."
        ],
        "note_long": "Streak of {} — very high chance of color change."
    }
}

HEAD_Y = (46, 96)
LEFT = (28, 112, 372, 606)
RIGHT = (390, 112, 872, 606)
STAT = (572, 46, 872, 96)
GRID_COLS = 12
GRID_ROWS = 6
GRID_CAP = GRID_COLS * GRID_ROWS

CHIP_C = (500, 236, 54)
PH_BUSY = 0.42
POP_LIFE = 0.6


# ───────────────────────── утилиты ─────────────────────────
def hex_rgb(h):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def mix(a, b, t):
    ra, rb = hex_rgb(a), hex_rgb(b)
    t = max(0.0, min(1.0, t))
    return "#%02x%02x%02x" % tuple(int(ra[i] + (rb[i] - ra[i]) * t) for i in range(3))


def ease_out_back(x):
    x = max(0.0, min(1.0, x))
    c1 = 1.70158
    c3 = c1 + 1
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2


def ease_in_out(x):
    x = max(0.0, min(1.0, x))
    return x * x * (3 - 2 * x)


def logit(p):
    p = min(max(p, 1e-3), 1 - 1e-3)
    return math.log(p / (1 - p))


def sigmoid(z):
    return 1 / (1 + math.exp(-z))


def streak_info(hist):
    if not hist:
        return None, 0
    c = hist[-1]
    n = 0
    for v in reversed(hist):
        if v == c:
            n += 1
        else:
            break
    return c, n


def max_streak(hist):
    best = cur = 0
    prev = None
    for v in hist:
        cur = cur + 1 if v == prev else 1
        prev = v
        best = max(best, cur)
    return best


# ───────────────────────── система шансов ─────────────────────────
class Engine:
    ORDER = ["streak", "pattern", "balance", "zigzag"]
    W0 = {"streak": 3.0, "pattern": 1.0, "balance": 0.8, "zigzag": 0.7}
    OPP0 = {1: 0.55, 2: 0.66, 3: 0.54, 4: 0.60, 5: 0.70, 6: 0.77, 7: 0.82, 8: 0.85, 9: 0.88}
    GAIN = 1.6

    def __init__(self):
        self.w = dict(self.W0)
        self.opp = dict(self.OPP0)
        self.hits = 0
        self.misses = 0

    @staticmethod
    def note(L, lang):
        l_pack = LANG[lang]
        if L <= 1:
            return l_pack["notes"][0]
        if L == 2:
            return l_pack["notes"][1]
        if L == 3:
            return l_pack["notes"][2]
        if L == 4:
            return l_pack["notes"][3]
        return l_pack["note_long"].format(L)

    def experts(self, hist):
        n = len(hist)
        out = {}
        last, L = streak_info(hist)
        po = self.opp[min(L, 9)]
        out["streak"] = (1 - po) if last == "R" else po

        p = 0.5
        for k in range(min(4, n - 1), 0, -1):
            pat = hist[-k:]
            r = b = 0
            for i in range(n - k):
                if hist[i:i + k] == pat:
                    if hist[i + k] == "R":
                        r += 1
                    else:
                        b += 1
            if r + b >= 2:
                p = (r + 1) / (r + b + 2)
                break
        out["pattern"] = p

        win = hist[-30:]
        nr = win.count("R")
        nb = len(win) - nr
        out["balance"] = min(0.9, max(0.1, 0.5 + 0.35 * (nb - nr) / len(win)))

        tail = hist[-7:]
        if len(tail) < 3:
            out["zigzag"] = 0.5
        else:
            alts = sum(1 for a, b in zip(tail, tail[1:]) if a != b) / (len(tail) - 1)
            po = 0.5 + 0.2 * (2 * alts - 1)
            out["zigzag"] = (1 - po) if last == "R" else po
        return out

    def predict(self, hist, lang="ru"):
        # Прогноз начинает работать только с 5 результатов
        if not hist or len(hist) < 5:
            return None
        hist = hist[-400:]
        ex = self.experts(hist)
        tw = sum(self.w.values())
        z = sum(self.w[k] * logit(ex[k]) for k in ex) / tw * self.GAIN
        pR = min(0.94, max(0.06, sigmoid(z)))
        pB = 1 - pR
        best = "R" if pR >= pB else "B"
        last, L = streak_info(hist)
        change = pB if last == "R" else pR
        d = abs(pR - 0.5)
        l_pack = LANG[lang]
        conf = l_pack["conf_low"] if d < 0.06 else (l_pack["conf_mid"] if d < 0.16 else l_pack["conf_high"])
        return {"pR": pR, "pB": pB, "best": best, "last": last, "L": L,
                "change": change, "same": 1 - change, "conf": conf,
                "experts": ex, "note": self.note(L, lang)}

    def learn(self, hist_before, actual, hit):
        if hit:
            self.hits += 1
        else:
            self.misses += 1
        if hist_before and len(hist_before) >= 5:
            hist_before = hist_before[-400:]
            ex = self.experts(hist_before)
            eta = 0.25 if hit else 0.6
            for k, p in ex.items():
                pa = p if actual == "R" else 1 - p
                self.w[k] *= math.exp(eta * (2 * pa - 1))
            s = sum(self.w.values())
            tot = sum(self.W0.values())
            for k in self.w:
                self.w[k] = min(6.0, max(0.3, self.w[k] * tot / s))
            last, L = streak_info(hist_before)
            key = min(L, 9)
            target = 1.0 if actual != last else 0.0
            lr = 0.06 if hit else 0.16
            self.opp[key] = min(0.92, max(0.35, self.opp[key] + lr * (target - self.opp[key])))


# ───────────────────────── графика (PIL → кэш) ─────────────────────────
_photo_cache = {}
_pil_cache = {}


def draw_snow(d, cx, cy, r, col, rot, width):
    for i in range(3):
        a = rot + i * math.pi / 3
        dx, dy = math.cos(a) * r, math.sin(a) * r
        d.line([cx - dx, cy - dy, cx + dx, cy + dy], fill=col, width=width)
        for s in (-1, 1):
            bx, by = cx + s * dx * 0.6, cy + s * dy * 0.6
            ang = a if s == 1 else a + math.pi
            for sg in (-1, 1):
                ba = ang + sg * 0.8
                d.line([bx, by, bx + math.cos(ba) * r * 0.3, by + math.sin(ba) * r * 0.3],
                       fill=col, width=width)


def render_snow(r, color, rot=0.0, width=1.0):
    ss = 4
    S = int(2 * r + 6)
    im = Image.new("RGBA", (S * ss, S * ss), (0, 0, 0, 0))
    c = S * ss / 2
    draw_snow(ImageDraw.Draw(im), c, c, r * ss, hex_rgb(color) + (255,), rot, max(1, int(width * ss)))
    return im.resize((S, S), RS.LANCZOS)


def snow_photo(r, color, width=1.0):
    key = ("snow", r, color, width)
    if key not in _photo_cache:
        _photo_cache[key] = ImageTk.PhotoImage(render_snow(r, color, 0.0, width))
    return _photo_cache[key]


def render_chip(c, r):
    base, edge = (hex_rgb(v) + (255,) for v in CHIP[c])
    big = r >= 30
    ss = 4
    pad = 12 if big else 2
    S = 2 * (r + pad)
    cc, R = S * ss / 2, r * ss
    im = Image.new("RGBA", (S * ss, S * ss), (0, 0, 0, 0))
    if big:
        ImageDraw.Draw(im).ellipse([cc - R + 4 * ss, cc - R + 8 * ss, cc + R + 4 * ss, cc + R + 8 * ss],
                                   fill=(4, 8, 20, 170))
        im = im.filter(ImageFilter.GaussianBlur(4 * ss))
    d = ImageDraw.Draw(im)
    d.ellipse([cc - R, cc - R, cc + R, cc + R], fill=base, outline=edge, width=(3 if big else 2) * ss)
    if r >= 12:
        w = max(3, round(r * 0.2))
        rb = (r - w // 2 - 3 + w / 2) * ss
        for i in range(8):
            d.arc([cc - rb, cc - rb, cc + rb, cc + rb], start=i * 45 - 11, end=i * 45 + 11,
                  fill=edge, width=int(w * ss))
        ri = int(r * 0.6) * ss
        d.ellipse([cc - ri, cc - ri, cc + ri, cc + ri], fill=base, outline=edge, width=2 * ss)
    if big:
        draw_snow(d, cc, cc, r * 0.3 * ss, edge, 0.0, ss)
    return im.resize((S, S), RS.LANCZOS)


def chip_pil(c, r):
    key = (c, r)
    if key not in _pil_cache:
        _pil_cache[key] = render_chip(c, r)
    return _pil_cache[key]


def chip_photo(c, r):
    key = ("chip", c, r)
    if key not in _photo_cache:
        _photo_cache[key] = ImageTk.PhotoImage(chip_pil(c, r))
    return _photo_cache[key]


def rr_photo(w, h, r, fill, outline, ow=1):
    key = ("rr", w, h, r, fill, outline, ow)
    p = _photo_cache.get(key)
    if p is None:
        ss = 4
        im = Image.new("RGBA", (w * ss, h * ss), (0, 0, 0, 0))
        ImageDraw.Draw(im).rounded_rectangle(
            [0, 0, w * ss - 1, h * ss - 1], radius=min(r, h // 2) * ss,
            fill=hex_rgb(fill) + (255,), outline=hex_rgb(outline) + (255,), width=ow * ss)
        p = ImageTk.PhotoImage(im.resize((w, h), RS.LANCZOS))
        _photo_cache[key] = p
    return p


# ───────────────────────── фон ─────────────────────────
def build_overlay(panels):
    s = 2
    img = Image.new("RGBA", (W * s, H * s), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    for (x1, y1, x2, y2) in panels:
        d.rounded_rectangle([x1 * s, y1 * s, x2 * s, y2 * s], radius=min(20, (y2 - y1) / 2) * s,
                            fill=PANEL_RGBA, outline=PANEL_OUT, width=s)
    img = img.resize((W, H), RS.LANCZOS)
    return img.convert("RGB"), img.getchannel("A")


class Scene:
    def __init__(self, panels):
        ys, xs = np.mgrid[0:BH, 0:BW]
        self.xs = (xs * BG_SCALE * 0.01).astype(np.float32)
        self.ys = (ys * BG_SCALE * 0.01).astype(np.float32)
        self.gy = (ys * BG_SCALE / H).astype(np.float32)
        self.diag = ((self.xs + self.ys) * 5.5).astype(np.float32)
        self.buf = np.empty((BH, BW, 3), np.uint8)
        self.ov_rgb, self.ov_mask = build_overlay(panels)

        rnd = random.Random(11)
        pal = [(255, 236, 190), (190, 215, 255), (255, 170, 180), (170, 255, 210)]
        self.sparks = [(rnd.uniform(0, W), rnd.uniform(0, H), rnd.uniform(0, 6.28),
                        rnd.uniform(0.5, 1.4), rnd.choice((1.0, 1.2, 1.6, 2.0)), rnd.choice(pal))
                       for _ in range(46)]

    def field(self, t):
        xs, ys = self.xs, self.ys
        a = np.sin(xs * 3.0 + t * 0.22 + np.sin(ys * 4.5 + t * 0.18) * 1.7)
        b = np.sin(ys * 5.0 - t * 0.20 + np.sin(xs * 2.8 - t * 0.15) * 2.0)
        c = np.sin((xs * 0.5 + ys * 0.9) * 4.0 + t * 0.14)
        s = np.sin(self.diag - t * 0.55)
        va, vb, vc = (a + 1) * 0.5, (b + 1) * 0.5, (c + 1) * 0.5
        sh = np.maximum(s, 0) ** 6 * 16
        gy = self.gy
        buf = self.buf
        buf[..., 0] = np.clip(7 + 12 * gy + 36 * vc * vc * vb + sh, 0, 255)
        buf[..., 1] = np.clip(9 + 10 * gy + 38 * va * va * vc + sh * 0.85, 0, 255)
        buf[..., 2] = np.clip(18 + 14 * gy + 46 * vb * va + sh * 0.35, 0, 255)
        return Image.fromarray(buf, "RGB")

    def frame(self, t):
        img = self.field(t).resize((W, H), RS.BILINEAR)
        d = ImageDraw.Draw(img)
        for (x, y, ph, sp, s, col) in self.sparks:
            b = math.sin(t * sp + ph)
            if b > 0.4:
                k = (b - 0.4) / 0.6
                c = (int(col[0] * k), int(col[1] * k), int(col[2] * k))
                r = s * (0.5 + 0.6 * k)
                d.ellipse([x - r, y - r, x + r, y + r], fill=c)
                if s >= 1.6 and k > 0.8:
                    d.line([(x - 3, y), (x + 3, y)], fill=c)
                    d.line([(x, y - 3), (x, y + 3)], fill=c)
        img.paste(self.ov_rgb, (0, 0), self.ov_mask)
        return img


# ───────────────────────── приложение ─────────────────────────
class App:
    def __init__(self, root):
        self.root = root
        root.title("br&roll")
        root.resizable(False, False)
        self.lang = "ru"

        self.cv = tk.Canvas(root, width=W, height=H, highlightthickness=0, bd=0, bg="#050812")
        self.cv.pack()

        title_font = tkfont.Font(family=FONT, size=22, weight="bold")
        tw = title_font.measure("br&roll")
        head = (28, HEAD_Y[0], 48 + tw + 22, HEAD_Y[1])

        self.scene = Scene([head, STAT, LEFT, RIGHT])
        self.engine = Engine()
        self.t0 = self.last = self.bg_t = time.time()

        self.photo = ImageTk.PhotoImage(Image.new("RGB", (W, H)))
        self.bg_item = self.cv.create_image(0, 0, anchor="nw", image=self.photo)

        for c in "RB":
            chip_photo(c, CHIP_C[2])
            chip_photo(c, 10)
            chip_photo(c, 17)
        self.snow_frames = [ImageTk.PhotoImage(render_snow(13, GOLD, i * (math.pi / 3) / 24, 2))
                            for i in range(24)]
        self.snow_idx = 0

        self.history = []
        self.pred = None
        self.hover = None
        self.btns = []
        self.bars = {"R": 0.0, "B": 0.0, "chg": 0.0, "same": 0.0}
        self.reveal_t0 = 0.0
        self.phase_t0 = None
        self.pop = None
        self.ghost = None
        self.particles = []
        self.keep = []

        self.dirty = True
        self.btn_dirty = True
        self.bars_dirty = True

        self.build_static(tw)

        self.cv.bind("<Motion>", self.on_motion)
        self.cv.bind("<Button-1>", self.on_click)
        self.cv.bind("<Leave>", self.on_leave)

        self.tick()

    @property
    def busy(self):
        return self.phase_t0 is not None

    def t(self, x, y, s, size=12, bold=False, fill=FG, anchor="w", tag="dyn", width=None, justify="left"):
        kw = {"width": width} if width else {}
        return self.cv.create_text(x, y, text=s, font=(FONT, size, "bold" if bold else "normal"),
                                   fill=fill, anchor=anchor, justify=justify, tags=tag, **kw)

    def img(self, x, y, photo, tag="dyn", anchor="center"):
        return self.cv.create_image(x, y, image=photo, anchor=anchor, tags=tag)

    def build_static(self, tw):
        cv = self.cv
        cy = (HEAD_Y[0] + HEAD_Y[1]) / 2
        self.t(48, cy, "br&roll", 22, True, tag="static")
        x1 = STAT[0]
        self.snow_item = cv.create_image(x1 + 30, cy, image=self.snow_frames[0], tags="static")
        self.t(x1 + 56, cy - 11, SYSTEM_NAME, 12, True, tag="static")

        for i in range(3):
            self.img(48 + i * 102, 154, rr_photo(96, 50, 12, CARD, CARD_OUT), "static", "nw")
            self.img(48 + i * 102, 212, rr_photo(96, 50, 12, CARD, CARD_OUT), "static", "nw")
        self.t(48, 284, "Внести результат", 10, False, DIM, tag="static")

        for i in range(4):
            ly = 172 + 48 * i
            self.img(590, ly + 10, rr_photo(262, 10, 5, TRACK, TRACK_OUT), "static", "nw")
        for i in range(4):
            self.img(410 + i * 112, 424, rr_photo(104, 38, 10, CARD, CARD_OUT), "static", "nw")
        cv.create_line(410, 474, 852, 474, fill="#2a3f6b", width=1, tags="static")

    def draw_dyn(self):
        cv = self.cv
        cv.delete("dyn")
        h = self.history
        p = self.pred
        e = self.engine
        l_pack = LANG[self.lang]
        cy = (HEAD_Y[0] + HEAD_Y[1]) / 2

        self.draw_lang_switcher()

        n = e.hits + e.misses
        if n == 0:
            sub = "точность — · ждёт ответов" if self.lang == "ru" else "accuracy — · awaiting"
        else:
            sub = f"точность {round(100 * e.hits / n)}% · зашло {e.hits} из {n}" if self.lang == "ru" \
                else f"accuracy {round(100 * e.hits / n)}% · hit {e.hits} of {n}"
        self.t(STAT[0] + 56, cy + 10, sub, 10, False, DIM)

        self.t(48, 138, l_pack["stats"], 13, True, tag="dyn")
        self.img(340, 138, snow_photo(8, GOLD), "dyn")

        nR, nB = h.count("R"), h.count("B")
        last, L = streak_info(h)
        cards1 = [(l_pack["NAME"]["R"], nR, "#ff8a98"), (l_pack["NAME"]["B"], nB, "#a9bde8"),
                  (f"{l_pack['series_lbl']} ({l_pack['SHORT'][last]})" if last else l_pack["series_lbl"],
                   L if L else "—", CHIP[last][1] if last else DIM)]
        cards2 = [(l_pack["max_streak"], max_streak(h) or "—", FG), (l_pack["hits_lbl"], e.hits, GREEN),
                  (l_pack["misses_lbl"], e.misses, AMBER)]
        for row, (cards, y) in enumerate(((cards1, 154), (cards2, 212))):
            for i, (lab, val, col) in enumerate(cards):
                cx_card = 48 + i * 102 + 48
                self.t(cx_card, y + 14, lab, 9, False, DIM, "center", tag="dyn")
                self.t(cx_card, y + 34, str(val), 17, True, col, "center", tag="dyn")

        self.t(48, 374, f"{l_pack['history']} · {len(h)}", 10, False, DIM)
        if not h:
            self.t(48, 402, l_pack["empty_history"], 11, False, DIM)
        recent = h[-GRID_CAP:]
        off = len(h) - len(recent)
        for j, c in enumerate(recent):
            if self.pop and self.pop[0] == off + j:
                continue
            self.img(60 + (j % GRID_COLS) * 25, 402 + (j // GRID_COLS) * 25, chip_photo(c, 10))

        self.t(410, 138, l_pack["predict_title"], 13, True, tag="dyn")
        self.t(852, 138, l_pack["eval_sys"], 9, False, DIM, "e", tag="dyn")

        self.t(410, 414, l_pack["signals"], 10, False, DIM)

        cx, cyy, R0 = CHIP_C
        self.t(cx, 306, l_pack["best_var"], 10, False, DIM, "center")
        if p:
            best = p["best"]
            self.t(cx, 328, l_pack["NAME"][best], 15, True, FG, "center")
            ccol = {l_pack["conf_low"]: AMBER, l_pack["conf_mid"]: GOLD, l_pack["conf_high"]: GREEN}[p["conf"]]
            self.t(cx, 350, f"{l_pack['confidence']}: {p['conf']}", 10, False, ccol, "center")
            self.img(418, 388, snow_photo(6, GOLD))
            self.t(436, 388, p["note"], 11, False, "#d8e6ff", width=416)
        else:
            self.t(cx, 328, "—", 15, True, DIM, "center")
            if not self.ghost:
                cv.create_oval(cx - R0, cyy - R0, cx + R0, cyy + R0, outline="#4a6194",
                               width=3, dash=(6, 6), tags="dyn")
                self.img(cx, cyy, snow_photo(22, "#4a6194", 2))
            
            # Показываем статус сколько осталось до 5 результатов
            if len(h) < 5:
                hint = f"{l_pack['need_more']} {len(h)}/5"
            else:
                hint = l_pack["calc"] if self.busy else l_pack["hint_empty"]

            self.t(cx, 352, hint, 9, False, DIM, "center", width=190, justify="center")
            self.t(410, 388, l_pack["note_default"], 11, False, DIM, width=442)

        for i, k in enumerate(Engine.ORDER):
            x1 = 410 + i * 112
            self.t(x1 + 52, 436, l_pack["titles"][k], 9, True, FG, "center")
            if p:
                pr = p["experts"][k]
                lean = "R" if pr >= 0.5 else "B"
                self.t(x1 + 52, 451, f"{l_pack['SHORT'][lean]} {max(pr, 1 - pr) * 100:.0f}%", 9, False,
                       GLOW[lean], "center")
                wv = min(1.0, e.w[k] / 6.0)
                cv.create_line(x1 + 10, 460, x1 + 10 + 84 * wv, 460, fill=GOLD, width=2, tags="dyn")
            else:
                self.t(x1 + 52, 451, "—", 9, False, DIM, "center")

        can = p is not None and not self.busy
        self.t(410, 492, l_pack["ask"], 12, True, FG if can else DIM)

    def draw_lang_switcher(self):
        title_font = tkfont.Font(family=FONT, size=22, weight="bold")
        tw = title_font.measure("br&roll")
        x_btn = 56 + tw + 10
        y_top = HEAD_Y[0] + 10
        target_lang_text = "EN" if self.lang == "ru" else "RU"
        self.button(x_btn, y_top, x_btn + 38, y_top + 28, "lang_switch", self.toggle_lang, 
                    target_lang_text, size=9, bold=True, r=6, tag="dyn")

    def toggle_lang(self):
        self.lang = "en" if self.lang == "ru" else "ru"
        self.dirty = self.btn_dirty = self.bars_dirty = True
        if self.history:
            self.pred = self.engine.predict(self.history, self.lang)

    def draw_btns(self):
        self.cv.delete("btn")
        self.btns = [b for b in self.btns if b[4] == "lang_switch"]
        free = not self.busy
        l_pack = LANG[self.lang]

        for c, x1 in (("R", 48), ("B", 206)):
            self.button(x1, 294, x1 + 146, 346, f"in_{c}", lambda c=c: self.add(c),
                        l_pack["NAME"][c], size=13, bold=True, r=14, tx=x1 + 58, anchor="w", enabled=free)
            self.img(x1 + 30, 320, chip_photo(c, 17), "btn")
        self.button(48, 556, 196, 592, "undo", self.undo, l_pack["btn_undo"], size=11, enabled=free)
        self.button(206, 556, 354, 592, "clear", self.clear, l_pack["btn_clear"], size=11, enabled=free)
        can = self.pred is not None and free
        self.button(410, 506, 624, 548, "hit", lambda: self.feedback(True), l_pack["hit"],
                    "#14382f", "#b8f5da", 13, True, "#3fae84", 14, enabled=can)
        self.button(638, 506, 852, 548, "miss", lambda: self.feedback(False), l_pack["miss"],
                    "#3d2a1c", "#ffd9b0", 13, True, "#c98a4b", 14, enabled=can)

    def button(self, x1, y1, x2, y2, key, cb, text="", fill=BTN, fg=FG, size=12,
               bold=False, outline=BTN_OUT, r=12, tx=None, anchor="center", enabled=True, tag="btn"):
        ow = 1
        if not enabled:
            fill, outline, fg = (mix(fill, PANEL_FADE, 0.5), mix(outline, PANEL_FADE, 0.55),
                                 mix(fg, PANEL_FADE, 0.55))
        elif self.hover == key:
            # Синяя подсветка при наведении без желтизны
            fill, outline, ow = mix(fill, "#ffffff", 0.09), BTN_ACTIVE_BLUE, 2
        self.img(x1, y1, rr_photo(x2 - x1, y2 - y1, r, fill, outline, ow), tag, "nw")
        if text:
            self.t(tx if tx is not None else (x1 + x2) / 2, (y1 + y2) / 2, text, size, bold, fg, anchor, tag)
        if enabled:
            self.btns = [b for b in self.btns if b[4] != key]
            self.btns.append((x1, y1, x2, y2, key, cb))

    def draw_bars(self):
        cv = self.cv
        cv.delete("bars")
        p = self.pred
        l_pack = LANG[self.lang]
        rows = [("R", l_pack["NAME"]["R"], "#e0546a"), ("B", l_pack["NAME"]["B"], "#8da2d8"),
                ("chg", l_pack["chg_bar"], "#f0cf7a"), ("same", l_pack["same_bar"], "#6fd6c9")]
        hl = {p["best"], "chg" if p["change"] >= 0.5 else "same"} if p else set()
        for i, (key, label, bcol) in enumerate(rows):
            ly = 172 + 48 * i
            self.t(590, ly, label, 11, key in hl, GOLD if key in hl else FG, tag="bars")
            v = self.bars[key]
            self.t(852, ly, "—" if v < 0.005 else f"{v * 100:.0f}%", 11, True, FG, "e", tag="bars")
            wpx = 262 * v
            if wpx > 3:
                x2 = 590 + max(5.5, wpx - 5)
                cv.create_line(595, ly + 15, x2, ly + 15, fill=bcol, width=8, capstyle="round", tags="bars")
                cv.create_line(598, ly + 13, max(599, x2 - 3), ly + 13, fill=mix(bcol, "#ffffff", 0.45),
                               width=1, tags="bars")
            cv.create_line(721, ly + 8, 721, ly + 22, fill="#4a6194", width=1, tags="bars")

    def chip_at(self, x, y, c, r, base_r):
        if r < 2.5:
            return
        k = r / base_r
        if abs(k - 1) < 0.02:
            ph = chip_photo(c, base_r)
        else:
            pil = chip_pil(c, base_r)
            size = (max(2, int(pil.width * k)), max(2, int(pil.height * k)))
            ph = ImageTk.PhotoImage(pil.resize(size, RS.BICUBIC))
            self.keep.append(ph)
        self.cv.create_image(x, y, image=ph, tags="anim")

    def draw_anim(self, now):
        cv = self.cv
        cv.delete("anim")
        self.keep = []
        cx, cy, R0 = CHIP_C
        p = self.pred

        if p:
            age = now - self.reveal_t0
            col = GLOW[p["best"]]
            for i in range(3):
                a = age - i * 0.2
                if 0 < a < 1.1:
                    f = a / 1.1
                    rr = R0 + 4 + f * 30
                    cv.create_oval(cx - rr, cy - rr, cx + rr, cy + rr,
                                   outline=mix(col, PANEL_FADE, 0.35 + 0.65 * f), width=2, tags="anim")
            br = 0.5 + 0.5 * math.sin(now * 2.2)
            rr = R0 + 7 + 3 * br
            cv.create_oval(cx - rr, cy - rr, cx + rr, cy + rr,
                           outline=mix(col, PANEL_FADE, 0.55 - 0.2 * br), width=2, tags="anim")
            self.chip_at(cx, cy, p["best"], R0 * ease_out_back(age / 0.55), R0)
        elif self.ghost:
            age = now - self.ghost[1]
            self.chip_at(cx, cy, self.ghost[0], R0 * (1 - ease_in_out(age / 0.4)), R0)

        if self.pop:
            idx, t0 = self.pop
            age = now - t0
            recent = len(self.history[-GRID_CAP:])
            j = idx - (len(self.history) - recent)
            if 0 <= j < recent:
                px, py = 60 + (j % GRID_COLS) * 25, 402 + (j // GRID_COLS) * 25
                c = self.history[idx]
                self.chip_at(px, py, c, 10 * ease_out_back(age / 0.4), 10)
                if age < POP_LIFE:
                    rr = 10 + age * 22
                    cv.create_oval(px - rr, py - rr, px + rr, py + rr,
                                   outline=mix(GLOW[c], PANEL_FADE, age / POP_LIFE), width=2, tags="anim")

        # ── СТРАХОВКА ЧАСТИЦ ОТ КОМПЛЕКСНЫХ ЧИСЕЛ И ОШИБОК ТИПОВ ──
        for q in self.particles:
            life = float(q["life"]) if q["life"] > 0 else 1.0
            raw_f = (now - q["t0"]) / life
            if hasattr(raw_f, "real"):
                raw_f = raw_f.real
            f = max(0.0, min(1.0, float(raw_f)))
            
            r = 3.2 * (1.0 - f) + 0.8
            ft = f ** 1.3
            if hasattr(ft, "real"):
                ft = ft.real
            ft = float(ft)

            rgb_parts = []
            for i in range(3):
                base_col = q["rgb"][i]
                if hasattr(base_col, "real"):
                    base_col = base_col.real
                fade_col = PANEL_FADE_RGB[i]
                val = float(base_col) + (float(fade_col) - float(base_col)) * ft
                if hasattr(val, "real"):
                    val = val.real
                rgb_parts.append(int(max(0.0, min(255.0, float(val)))))
            
            c = "#%02x%02x%02x" % tuple(rgb_parts)
            cv.create_oval(q["x"] - r, q["y"] - r, q["x"] + r, q["y"] + r, fill=c, outline="", tags="anim")

    def anim_active(self):
        return (self.pred is not None or bool(self.particles) or self.ghost is not None
                or self.pop is not None)

    def update_anim(self, now, dt):
        tg = {"R": 0.0, "B": 0.0, "chg": 0.0, "same": 0.0}
        if self.pred:
            tg = {"R": self.pred["pR"], "B": self.pred["pB"],
                  "chg": self.pred["change"], "same": self.pred["same"]}
        k = 1 - math.exp(-dt * 7)
        for key in self.bars:
            diff = tg[key] - self.bars[key]
            if diff == 0:
                continue
            self.bars[key] = tg[key] if abs(diff) < 0.0015 else self.bars[key] + diff * k
            self.bars_dirty = True

        if self.phase_t0 is not None and now - self.phase_t0 >= PH_BUSY:
            self.phase_t0 = None
            self.set_pred(self.engine.predict(self.history, self.lang))
            self.dirty = self.btn_dirty = True

        if self.pop and now - self.pop[1] > POP_LIFE:
            self.pop = None
            self.dirty = True
        if self.ghost and now - self.ghost[1] > 0.4:
            self.ghost = None
            self.dirty = True

        if self.particles:
            damp = math.exp(-dt * 1.5)
            alive = []
            for q in self.particles:
                if now - q["t0"] < q["life"]:
                    q["x"] += q["vx"] * dt
                    q["y"] += q["vy"] * dt
                    q["vx"] *= damp
                    q["vy"] = q["vy"] * damp + 25 * dt
                    alive.append(q)
            self.particles = alive[-60:]

    def burst(self, x, y, n, colors):
        now = time.time()
        for _ in range(n):
            ang = random.uniform(0, 2 * math.pi)
            sp = random.uniform(40, 130)
            self.particles.append({"x": x, "y": y, "vx": math.cos(ang) * sp, "vy": math.sin(ang) * sp,
                                   "t0": now, "life": random.uniform(0.7, 1.3),
                                   "rgb": hex_rgb(random.choice(colors))})

    def set_pred(self, p):
        self.pred = p
        self.reveal_t0 = time.time()
        self.dirty = self.btn_dirty = self.bars_dirty = True
        if p:
            self.burst(CHIP_C[0], CHIP_C[1], 12, [GOLD, "#ffffff", GLOW[p["best"]]])

    def tick(self):
        t0 = time.perf_counter()
        now = time.time()
        if self.root.state() == "iconic":
            self.last = now
            self.root.after(250, self.tick)
            return
        dt = min(0.1, now - self.last)
        self.last = now
        self.update_anim(now, dt)

        if now - self.bg_t >= BG_DT:
            self.bg_t = now
            try:
                self.photo.paste(self.scene.frame(now - self.t0))
            except Exception:
                pass
            self.snow_idx = (self.snow_idx + 1) % len(self.snow_frames)
            self.cv.itemconfig(self.snow_item, image=self.snow_frames[self.snow_idx])

        if self.dirty:
            self.draw_dyn()
            self.dirty = False
        if self.btn_dirty:
            self.draw_btns()
            self.btn_dirty = False
        if self.bars_dirty:
            self.draw_bars()
            self.bars_dirty = False
        if self.anim_active() or self.keep:
            self.draw_anim(now)
        else:
            self.cv.delete("anim")

        spent = (time.perf_counter() - t0) * 1000
        self.root.after(max(1, int(FRAME_MS - spent)), self.tick)

    def find(self, x, y):
        for (x1, y1, x2, y2, key, cb) in reversed(self.btns):
            if x1 <= x <= x2 and y1 <= y <= y2:
                return key
        return None

    def on_motion(self, e):
        key = self.find(e.x, e.y)
        if key != self.hover:
            self.hover = key
            self.cv.config(cursor="hand2" if key else "")
            self.btn_dirty = True

    def on_leave(self, _):
        if self.hover is not None:
            self.hover = None
            self.btn_dirty = True

    def on_click(self, e):
        key = self.find(e.x, e.y)
        if key is None:
            return
        for (x1, y1, x2, y2, k, cb) in reversed(self.btns):
            if k == key:
                self.hover = None
                cb()
                break

    def add(self, c):
        if self.busy:
            return
        self.history.append(c)
        self.pop = (len(self.history) - 1, time.time())
        self.set_pred(self.engine.predict(self.history, self.lang))

    def undo(self):
        if self.busy or not self.history:
            return
        self.history.pop()
        self.pop = None
        self.set_pred(self.engine.predict(self.history, self.lang))

    def clear(self):
        if self.busy:
            return
        self.history.clear()
        self.pop = None
        self.set_pred(None)

    def feedback(self, hit):
        if self.pred is None or self.busy:
            return
        now = time.time()
        best = self.pred["best"]
        actual = best if hit else ("B" if best == "R" else "R")
        self.engine.learn(list(self.history), actual, hit)
        self.history.append(actual)
        self.pop = (len(self.history) - 1, now)
        self.ghost = (best, now)
        self.phase_t0 = now
        self.pred = None
        self.dirty = self.btn_dirty = self.bars_dirty = True
        if hit:
            self.burst(CHIP_C[0], CHIP_C[1], 26, [GREEN, GOLD, "#ffffff"])
        else:
            self.burst(CHIP_C[0], CHIP_C[1], 14, [AMBER, "#ffffff"])


if __name__ == "__main__":
    try:
        import ctypes
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        pass
    root = tk.Tk()
    App(root)
    root.mainloop()
